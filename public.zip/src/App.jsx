import './css/style.css'
import Todo from './componets/Todo'

function App() {
  

  return (
    <>
      <Todo/>
    </>
  )
}

export default App
